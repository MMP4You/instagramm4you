<?php

return [
    'instagramm4you-plugin-instagramfe' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:instagramm4you/Resources/Public/Icons/user_plugin_instagramfe.svg'
    ],
];
