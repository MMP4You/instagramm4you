<?php
defined('TYPO3') || die();

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('instagramm4you', 'Configuration/TypoScript', 'Instagramm4You');
