function toggleshow(){






}


$( ".instreadmore" ).click(function() {
    alert( "Handler for .click() called." );
});