CREATE TABLE tx_instagramm4you_domain_model_instafeeds (
	accestoken text NOT NULL DEFAULT ''
);
